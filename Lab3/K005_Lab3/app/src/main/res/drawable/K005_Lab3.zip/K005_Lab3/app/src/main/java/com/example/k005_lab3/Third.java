package com.example.k005_lab3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
public class Third extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);
    }
}
