package com.example.new_app;

import android.os.Bundle;

// For Android app components and UI
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.ViewGroup;
import android.text.TextWatcher;
import android.text.Editable;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

// For lists and arrays
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    EditText etNumSubjects;
    Button btnNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNumSubjects = findViewById(R.id.etNumSubjects);
        btnNext = findViewById(R.id.btnNext);

        btnNext.setOnClickListener(v -> {
            String numStr = etNumSubjects.getText().toString();
            if (!numStr.isEmpty()) {
                int numSubjects = Integer.parseInt(numStr);
                Intent intent = new Intent(MainActivity.this, SubjectsActivity.class);
                intent.putExtra("numSubjects", numSubjects);
                startActivity(intent);
            }
        });
    }
}
