package com.example.new_app;

// For Android app components and UI
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.view.ViewGroup;
import android.text.TextWatcher;
import android.text.Editable;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

// For lists and arrays
import java.util.ArrayList;
import java.util.List;

public class SubjectsActivity extends AppCompatActivity {
    LinearLayout subjectsContainer;
    Button btnSave;
    int numSubjects;
    List<EditText> subjectNames = new ArrayList<>();
    List<EditText> missableLectures = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects);

        subjectsContainer = findViewById(R.id.subjectsContainer);
        btnSave = findViewById(R.id.btnSave);

        numSubjects = getIntent().getIntExtra("numSubjects", 1);

        for (int i = 0; i < numSubjects; i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            EditText etName = new EditText(this);
            etName.setHint("Subject Name");
            etName.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            subjectNames.add(etName);

            EditText etMissable = new EditText(this);
            etMissable.setHint("Can be Missed");
            etMissable.setInputType(InputType.TYPE_CLASS_NUMBER);
            etMissable.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            missableLectures.add(etMissable);

            row.addView(etName);
            row.addView(etMissable);

            subjectsContainer.addView(row);
        }

        btnSave.setOnClickListener(v -> {
            ArrayList<String> names = new ArrayList<>();
            ArrayList<Integer> missable = new ArrayList<>();
            for (int i = 0; i < numSubjects; i++) {
                names.add(subjectNames.get(i).getText().toString());
                missable.add(Integer.parseInt(missableLectures.get(i).getText().toString()));
            }
            Intent intent = new Intent(SubjectsActivity.this, DashboardActivity.class);
            intent.putStringArrayListExtra("names", names);
            intent.putIntegerArrayListExtra("missable", missable);
            startActivity(intent);
        });
    }
}
