package com.example.new_app;

// For Android app components and UI
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.text.InputType;
import android.view.ViewGroup;
import android.text.TextWatcher;
import android.text.Editable;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

// For lists and arrays
import java.util.ArrayList;
import java.util.List;

public class DashboardActivity extends AppCompatActivity {
    LinearLayout tableContainer;
    ArrayList<String> names;
    ArrayList<Integer> missable;
    List<EditText> missedLectures = new ArrayList<>();
    List<TextView> stillCanMiss = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        tableContainer = findViewById(R.id.tableContainer);

        names = getIntent().getStringArrayListExtra("names");
        missable = getIntent().getIntegerArrayListExtra("missable");

        // Table Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.addView(makeTextView("Subject"));
        header.addView(makeTextView("Can Miss"));
        header.addView(makeTextView("Missed"));
        header.addView(makeTextView("Still Can Miss"));
        tableContainer.addView(header);

        for (int i = 0; i < names.size(); i++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);

            TextView tvName = makeTextView(names.get(i));
            TextView tvMissable = makeTextView(String.valueOf(missable.get(i)));

            EditText etMissed = new EditText(this);
            etMissed.setInputType(InputType.TYPE_CLASS_NUMBER);
            etMissed.setText("0");
            etMissed.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
            missedLectures.add(etMissed);

            TextView tvStill = makeTextView(String.valueOf(missable.get(i)));
            stillCanMiss.add(tvStill);

            int finalI = i;
            etMissed.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override
                public void afterTextChanged(Editable s) {
                    int missed = 0;
                    try { missed = Integer.parseInt(s.toString()); } catch (Exception e) {}
                    int canStillMiss = missable.get(finalI) - missed;
                    stillCanMiss.get(finalI).setText(String.valueOf(canStillMiss));
                }
            });

            row.addView(tvName);
            row.addView(tvMissable);
            row.addView(etMissed);
            row.addView(tvStill);

            tableContainer.addView(row);
        }
    }

    private TextView makeTextView(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        return tv;
    }
}
